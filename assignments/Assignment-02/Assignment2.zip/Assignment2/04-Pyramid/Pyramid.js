/*
 * File: Pyramid.js
 * ----------------
 * This program draws a pyramid consisting of staggered rows of bricks,
 * each of which has the dimensions BRICK_WIDTH x BRICK_HEIGHT.  The
 * base of the pyramid consists of BRICKS_IN_BASE bricks, with each
 * successive layer one step shorter.  The pyramid is centered in the
 * graphics window.
 */

import "graphics";

/* Constants */

const GWINDOW_WIDTH = 500;
const GWINDOW_HEIGHT = 300;
const BRICK_WIDTH = 30;
const BRICK_HEIGHT = 14;
const BRICKS_IN_BASE = 15;

/* Main program */

function Pyramid() {
   // Add the definition of Pyramid and add any helper functions you need
}
