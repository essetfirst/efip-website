/*
 * File: Fibonacci.js
 * ------------------
 * This file implements the function fib(n) which computes the nth term
 * in the Fibonacci sequence.
 */

/*
 * This function prints the terms in the Fibonacci sequence between the
 * limits min and max.
 */

function fibonacciTable(min, max) {
   // Fill in the body of this function
}

/*
 * This function returns the nth term in the Fibonacci sequence.  The value
 * of fib(0) and fib(1) are 0 and 1, respectively; the value of every
 * subsequent term is the sum of the preceding two.
 */

function fib(n) {
   // Fill in the definition of fib
}
