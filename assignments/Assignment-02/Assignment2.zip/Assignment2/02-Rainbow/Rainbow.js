/*
 * File: Rainbow.js
 * ----------------
 * The program defines the function rainbow, which displays a rainbow on
 * the graphics window.  This program does not actually draw circular
 * stripes but instead overlays successively smaller circles on top of
 * each other so that only the stripe remains showing.
 */

import "graphics";

/*
 * Displays a rainbow on the graphics window.
 */

function Rainbow() {
   // Fill in the definition of Rainbow and add any helper functions you need
}
