/*
 * File: Newspeak.js
 * -----------------
 * This file contains functions to implement several of the standard
 * prefixes used in the Newspeak language described in George Orwell's
 * novel 1984.
 */

// Add definitions of the functions negate, intensify, and reinforce
