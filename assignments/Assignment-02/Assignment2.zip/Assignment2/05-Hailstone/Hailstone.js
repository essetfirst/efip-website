/*
 * File: Hailstone.sjs
 * -------------------
 * This program computes the Hailstone sequence for a number.  The steps
 * in the Hailstone process are as follows:
 *
 *   Start with e positive integer n.
 *   If n is even, divide it by two.
 *   If n is odd, multiply it by three and add one.
 *   Continue this process until n is equal to one.
 *
 * The question of whether this process always terminates remains unanswered.
 */

function hailstone(n) {
   // Fill in the definition of hailstone
}
